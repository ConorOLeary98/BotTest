# Girls Frontline T-Doll Bot
Discord bot that grabs information on specific t-dolls.

Example of the ?gf command:  
![](https://i.imgur.com/i6ECYVE.png)  
  
Example of the ?gfroll command:  
![](https://i.imgur.com/v31sUBe.png)
