import discord
import os
import asyncio
import requests
import operator
from bs4 import BeautifulSoup
import urllib.request as urllib2
from config import Config

client = discord.Client()
say = client.send_message
server_list = []

@client.event
async def on_ready():
    os.system('clear')
    print("="*20)
    print("Logging in as: ", client.user.name)
    print("Bot ID: ", client.user.id)
    print("="*20)
    print("Server List")
    print("-"*15)
    for server in client.servers:
        server_list.append(server)
        print(server)
    print("="*20)
    await client.change_presence(game=discord.Game(name='?gfhelp'))

@client.event
async def on_message(message):
    cont = message.content
    channel = message.channel
    auth = message.author

    if cont.startswith('?gfhelp'):
        help_message = '``` \
        Gunfu Bot Commands: \n \
        "?gf t-doll": Shows images and stats about a specific t-doll. \n \
        "?gfnt t-doll": Shows images only of a specific t-doll. \n \
        "?gfroll t-doll": Shows top 3 recipies for the specific t-doll (not yet implemented).\
        ```'
        await say(channel, help_message)

    elif cont.startswith('?gf '):
        print('<{}> {}: {}'.format(message.server, auth, cont))
        lookup_item = ''
        try:
            # Format of messages "?gf WA2000"
            lookup_item = cont.strip('?gf ').replace(' ', '_')
            print(lookup_item)
        except:
            await say(channel, "Correct command usage ```?gf WA2000```")
            return

        # Scraping wiki page
        link = "https://en.gfwiki.com/wiki/" + lookup_item
        try:
            page = urllib2.urlopen(link)
        except:
            await say(channel, "No results found! Capitilization matters!")
            return
        soup = BeautifulSoup(page, 'lxml')
        # check if page exists/has info
        if (soup.find('div', {'class': 'noarticletext mw-content-ltr'}) != None):
            await say(channel, "No results found!")
            return
        await client.send_typing(channel)
        # finding full image
        image_link = soup.find('div', {"class": "fullart"}).find('img')['src']
        image_link = "https://en.gfwiki.com" + image_link

        # Grab star count
        stars = 0
        # Can't find info on stars past the image that gets generated, so this may be a little inefficient.
        for img in soup.find('div', {'class': 'card-bg'}).find_all('img'):
            if img['src'] == "https://en.gfwiki.com/images/8/86/Icon_star.png":
                stars += 1
        colors = [0xffffff, 0x6bfffc, 0xc0f986, 0xffc300]
        embed_color = colors[stars-2]

        # Grab weapon type
        type = soup.find('div', {'class': 'card-bg'}).find_all('img')[1]['src']

        # Grab Weapon Background Paragraph
        weapon_background = "Something went wrong on grabbing this info."
        k = 0
        for item in soup.find('div', {'id': 'bodyContent'}).find_all('p'):
            print(item.text, " ", k)
            k += 1
            if len(item.text) >= 100:
                weapon_background = item.text
                print(weapon_background)
                break

        # Grab stats
        stat_result = soup.find('div', {'class': 'verticaltabber paddedtabber-2px costumeContainer stattable'})
        needed = ['dmg', 'acc', 'eva', 'rof']
        full_name_needed = ['Damage', 'Accuracy', 'Evasion', 'Rate Of Fire']
        stats = []
        for item in needed:
            # Create a tuple of (min, max) for each stat
            stats.append( (int(stat_result.find('td', {'data-tdoll-stat-id': 'min_'+item+'_t'}).text), int(stat_result.find('td', {'data-tdoll-stat-id': 'max_'+item+'_t'}).text)) )

        # Discord has a 2000 character limit, discord.py will throw an error if it's above that.
        if len(weapon_background) > 1500:
            weapon_background = weapon_background[:1500] + "... For more info -> " + "https://en.gfwiki.com/wiki/" + lookup_item

        # request url https://en.gfwiki.com/api.php?action=query&titles=File:WA2000.png&format=json&prop=imageinfo&iiprop=url
        # image link https://en.gfwiki.com/images/0/0e/GSh-18.png
        embed_message = discord.Embed(
        title = '',
        description = "{} star t-doll".format(stars),
        color = embed_color
        ).set_author(
        name=lookup_item.replace('UMP45', 'Worst Gunfu'),
        icon_url='https://en.gfwiki.com/images/c/c9/Logo.png',
        url="https://en.gfwiki.com/wiki/" + lookup_item
        ).set_image(
        url=image_link
        ).set_thumbnail(
        url=type
        ).set_footer(
        text="All data pulled from https://en.gfwiki.com"
        ).add_field(
        name="Weapon Background",
        value=weapon_background
        )

        index = 0
        for item in full_name_needed:
            embed_message.add_field(
            name=item,
            value="{} -> {}".format(stats[index][0], stats[index][1])
            )
            index += 1
        await say(channel, embed=embed_message)

    elif cont.startswith('?gfnt '):
        print('<{}> {}: {}'.format(message.server, auth, cont))
        lookup_item = ''
        try:
            # Format of messages "?gf WA2000"
            lookup_item = cont.strip('?gfnt ').replace(' ', '_')
            print(lookup_item)
        except:
            await say(channel, "Correct command usage ```?gfnt WA2000```")
            return

        link = "https://en.gfwiki.com/wiki/" + lookup_item
        try:
            page = urllib2.urlopen(link)
        except:
            await say(channel, "No results found! Capitilization matters!")
            return
        soup = BeautifulSoup(page, 'lxml')
        # check if page exists/has info
        if (soup.find('div', {'class': 'noarticletext mw-content-ltr'}) != None):
            await say(channel, "No results found!")
            return

        # Find Image link
        image_link = soup.find('div', {"class": "fullart"}).find('img')['src']
        image_link = "https://en.gfwiki.com" + image_link

        # Grab star count
        stars = 0
        # Can't find info on stars past the image that gets generated, so this may be a little inefficient.
        for img in soup.find('div', {'class': 'card-bg'}).find_all('img'):
            if img['src'] == "https://en.gfwiki.com/images/8/86/Icon_star.png":
                stars += 1
        colors = [0xffffff, 0x6bfffc, 0xc0f986, 0xffc300]
        embed_color = colors[stars-2]

        # Grab weapon type
        type = soup.find('div', {'class': 'card-bg'}).find_all('img')[1]['src']

        embed_message = discord.Embed(
        title = '',
        color = embed_color
        ).set_author(
        name=lookup_item,
        icon_url='https://en.gfwiki.com/images/c/c9/Logo.png'
        ).set_image(
        url=image_link
        ).set_thumbnail(
        url=type
        ).set_footer(
        text="All data pulled from https://en.gfwiki.com"
        )

        await say(channel, embed=embed_message)

    elif cont.startswith('?gfroll '):
        print('<{}> {}: {}'.format(message.server, auth, cont))
        lookup_item = ''
        try:
            # Format of messages "?gf WA2000"
            lookup_item = cont.strip('?gfroll ').replace(' ', '_')
            print(lookup_item)
        except:
            await say(channel, "Correct command usage ```?gfnt WA2000```")
            return

        link = "https://en.gfwiki.com/wiki/" + lookup_item
        try:
            page = urllib2.urlopen(link)
        except:
            await say(channel, "No results found! Capitilization matters!")
            return

        await client.send_typing(channel)
        # Finding ID of t-doll
        data = requests.get("https://ipick.baka.pw:444/data/json/gun_info_simple").json()
        id = -1
        for item in data:
            if item['code'] == lookup_item:
                id = int(item['id'])
                duration = int(item['develop_duration'])
        if id == -1:
            await say(channel, "Something isn't quite right...")
            return

        data = requests.get("https://ipick.baka.pw:444/stats/tdoll/id/"+str(id)).json()
        # Messy way of finding the sorted data ( id, percentage )
        sorted_tuples = []
        i = 0
        for item in data:
            if int(item['formula']['mp']) >= 1000:
                data.remove(item)
                continue
            sorted_tuples.append ((item, int(item['count']) / int(item['total'])) )
            i += 1
        sorted_tuples.sort(key=operator.itemgetter(1), reverse=True)
        # I tried okay -> data = sorted(data, key=lambda x: (int(x[x]['count']) / int(x[x]['total'])))


        result = []
        # Find top 3 results for production chances in list [rank, chance, [recepie]]
        rank_amount = len(data)
        i = 0
        while i < 3:
            r = sorted_tuples[i][0]
            form = r['formula']
            rank = i
            chance = round(sorted_tuples[i][1] * 100, 2)
            recepie = [form['mp'], form['ammo'], form['mre'], form['part']]
            result.append([rank+1, chance, recepie])
            i += 1

        # Convert duration to H:M format
        m, s = divmod(duration, 60)
        h, m = divmod(m, 60)

        embed_message = discord.Embed(
        title='',
        color=0xffc300
        ).set_author(
        name="{} Top Recepies \u231B {}:{}".format(lookup_item, h, m)
        ).set_thumbnail(
        url="http://gfdb.baka.pw/img/iop.jpg"
        ).set_footer(
        text="All recepie data grabbed from http://gfdb.baka.pw/statistician.html"
        )

        for item in result:
            embed_message.add_field(
            name="Recepie Rank #{} - {}% chance".format(item[0], item[1]),
            value='{}, {}, {}, {}'.format(item[2][0], item[2][1], item[2][2], item[2][3]),
            inline=False
            )
        await say(channel, embed=embed_message)

# Replace Config.getToken() with your bot token
client.run( Config.getToken() )
